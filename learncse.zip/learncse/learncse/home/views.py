from django.shortcuts import render
from .models import *

def home(request):
    return render(request,'home.html')

def about(request):
    propnot=Notice.objects.all()
    return render(request,"about.html",{'propnotice':propnot})

def library(request):
    return render(request,"library.html")
def takenote(request):
    return render(request,"takenote.html")


def compiler(request):
    propc = Compiler.objects.all()
    return render(request,'compiler.html',{'propcompiler':propc})


def clang(request):
    propcl = Clanguage.objects.all()
    return render(request,'clang.html',{'propclanguage':propcl})

def network(request):
    propcn = ComputerNetwork.objects.all()
    return render(request,'cnetwork.html',{'propnetwork':propcn})


def organization(request):
    propco = ComputerOrganization.objects.all()
    return render(request,'corg.html',{'proporganization':propco})


def operating(request):
    propos = OperatingSystem.objects.all()
    return render(request,'osys.html',{'propsystem':propos})


def dbms(request):
    propdbm = DataBaseManagement.objects.all()
    return render(request,'dbms.html',{'propdbms':propdbm})



def computation(request):
    proptoc = TheoryofComputation.objects.all()
    return render(request,'toc.html',{'propcomputation':proptoc})



def aptitude(request):
    propapti = Aptitude.objects.all()
    return render(request ,'apti.html',{'propaptitude':propapti})




def electronics(request):
    propdelec = DigitalElectronics.objects.all()
    return render(request,'delec.html',{'propelectrics':propdelec})





def discrete(request):
    propdm = DiscreteMathematics.objects.all()
    return render(request,'dmat.html',{'propdmaths':propdm})





def software(request):
    propse = SoftwareEngineering.objects.all()
    return render(request,'sengg.html',{'propsoftware':propse})




def notes(request):
    propmen = MadeEasyNotes.objects.all()
    return render(request,'menotes.html',{'propnotes':propmen})




def workbook(request):
    propmew = MadeEasyWorkbooks.objects.all()
    return render(request,'mework.html',{'propwork':propmew})




def handnotes(request):
    prophw = HandNotes.objects.all()
    return render(request,'hwrite.html',{'propwrnotes':prophw})


