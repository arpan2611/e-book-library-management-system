from django.urls import path
from .import views


urlpatterns=[
    path('',views.home,name="Home"),
    path('about/',views.about,name="About"),
    path('library/',views.library,name="Library"),
    path('compiler/',views.compiler,name = "Compiler"),
    path('clanguage/',views.clang ,name="Clang"),
    path('cn/',views.network ,name="Network"),
    path('co/',views.organization,name="Organization"),
    path('os/',views.operating,name="Operating"),
    path('dbms/',views.dbms ,name="Dbms"),
    path('toc/',views.computation ,name="Computation"),
    path('apti/',views.aptitude ,name="Aptitude"),
    path('de/',views.electronics ,name="Digital"),
    path('dm/',views.discrete ,name="Discrete"),
    path('se/',views.software ,name="Software"),
    path('men/',views.notes ,name="Notes"),
    path('mew/',views.workbook ,name="Workbook"),
    path('hwn/',views.handnotes ,name="Handnotes"),
    path('takenote/',views.takenote,name="Takenote")
]