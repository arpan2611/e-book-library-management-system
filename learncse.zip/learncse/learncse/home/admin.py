from django.contrib import admin
from . models import *
# Register your models here.


admin.site.register(Compiler)
admin.site.register(Clanguage)
admin.site.register(ComputerNetwork)
admin.site.register(ComputerOrganization)
admin.site.register(OperatingSystem)
admin.site.register(DataBaseManagement)
admin.site.register(TheoryofComputation)
admin.site.register(Aptitude)
admin.site.register(DigitalElectronics)
admin.site.register(DiscreteMathematics)
admin.site.register(SoftwareEngineering)
admin.site.register(MadeEasyNotes)
admin.site.register(MadeEasyWorkbooks)
admin.site.register(HandNotes)
admin.site.register(Notice)