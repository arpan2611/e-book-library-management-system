from django.db import models

# Create your models here.






class Compiler(models.Model):
    name = models.CharField(max_length=220, null=True)
    author = models.CharField(max_length=70,null=True)
    image = models.ImageField(null=True, blank=False)
    download_link = models.CharField(max_length=500,null=True)

    def __str__(self):
        return self.name

    @property
    def imageURL(self):
        try:
            url = self.image.url
        except:
            url = ''
        return url



class Clanguage(models.Model):
    name = models.CharField(max_length=220, null=True)
    author = models.CharField(max_length=70,null=True)
    image = models.ImageField(null=True, blank=False)
    download_link = models.CharField(max_length=500,null=True)

    def __str__(self):
        return self.name

    @property
    def imageURL(self):
        try:
            url = self.image.url
        except:
            url = ''
        return url


class ComputerNetwork(models.Model):
    name = models.CharField(max_length=220, null=True)
    author = models.CharField(max_length=70,null=True)
    image = models.ImageField(null=True, blank=False)
    download_link = models.CharField(max_length=500,null=True)

    def __str__(self):
        return self.name

    @property
    def imageURL(self):
        try:
            url = self.image.url
        except:
            url = ''
        return url



class ComputerOrganization(models.Model):
    name = models.CharField(max_length=220, null=True)
    author = models.CharField(max_length=70,null=True)
    image = models.ImageField(null=True, blank=False)
    download_link = models.CharField(max_length=500,null=True)

    def __str__(self):
        return self.name

    @property
    def imageURL(self):
        try:
            url = self.image.url
        except:
            url = ''
        return url

class OperatingSystem(models.Model):
    name = models.CharField(max_length=220, null=True)
    author = models.CharField(max_length=70,null=True)
    image = models.ImageField(null=True, blank=False)
    download_link = models.CharField(max_length=500,null=True)

    def __str__(self):
        return self.name

    @property
    def imageURL(self):
        try:
            url = self.image.url
        except:
            url = ''
        return url

class DataBaseManagement(models.Model):
    name = models.CharField(max_length=220, null=True)
    author = models.CharField(max_length=70,null=True)
    image = models.ImageField(null=True, blank=False)
    download_link = models.CharField(max_length=500,null=True)

    def __str__(self):
        return self.name

    @property
    def imageURL(self):
        try:
            url = self.image.url
        except:
            url = ''
        return url


class TheoryofComputation(models.Model):
    name = models.CharField(max_length=220, null=True)
    author = models.CharField(max_length=70,null=True)
    image = models.ImageField(null=True, blank=False)
    download_link = models.CharField(max_length=500,null=True)

    def __str__(self):
        return self.name

    @property
    def imageURL(self):
        try:
            url = self.image.url
        except:
            url = ''
        return url



class Aptitude(models.Model):
    name = models.CharField(max_length=220, null=True)
    author = models.CharField(max_length=70,null=True)
    image = models.ImageField(null=True, blank=False)
    download_link = models.CharField(max_length=500,null=True)

    def __str__(self):
        return self.name

    @property
    def imageURL(self):
        try:
            url = self.image.url
        except:
            url = ''
        return url



class DigitalElectronics(models.Model):
    name = models.CharField(max_length=220, null=True)
    author = models.CharField(max_length=70,null=True)
    image = models.ImageField(null=True, blank=False)
    download_link = models.CharField(max_length=500,null=True)

    def __str__(self):
        return self.name

    @property
    def imageURL(self):
        try:
            url = self.image.url
        except:
            url = ''
        return url




class DiscreteMathematics(models.Model):
    name = models.CharField(max_length=220, null=True)
    author = models.CharField(max_length=70,null=True)
    image = models.ImageField(null=True, blank=False)
    download_link = models.CharField(max_length=500,null=True)

    def __str__(self):
        return self.name

    @property
    def imageURL(self):
        try:
            url = self.image.url
        except:
            url = ''
        return url






class SoftwareEngineering(models.Model):
    name = models.CharField(max_length=220, null=True)
    author = models.CharField(max_length=70,null=True)
    image = models.ImageField(null=True, blank=False)
    download_link = models.CharField(max_length=500,null=True)

    def __str__(self):
        return self.name

    @property
    def imageURL(self):
        try:
            url = self.image.url
        except:
            url = ''
        return url




class MadeEasyNotes(models.Model):
    name = models.CharField(max_length=220, null=True)
    author = models.CharField(max_length=70,null=True)
    image = models.ImageField(null=True, blank=False)
    download_link = models.CharField(max_length=500,null=True)

    def __str__(self):
        return self.name

    @property
    def imageURL(self):
        try:
            url = self.image.url
        except:
            url = ''
        return url





class MadeEasyWorkbooks(models.Model):
    name = models.CharField(max_length=220, null=True)
    author = models.CharField(max_length=70,null=True)
    image = models.ImageField(null=True, blank=False)
    download_link = models.CharField(max_length=500,null=True)

    def __str__(self):
        return self.name

    @property
    def imageURL(self):
        try:
            url = self.image.url
        except:
            url = ''
        return url



class HandNotes(models.Model):
    name = models.CharField(max_length=220, null=True)
    author = models.CharField(max_length=70,null=True)
    image = models.ImageField(null=True, blank=False)
    download_link = models.CharField(max_length=500,null=True)

    def __str__(self):
        return self.name

    @property
    def imageURL(self):
        try:
            url = self.image.url
        except:
            url = ''
        return url


class Notice(models.Model):
    name=models.CharField(max_length=100,null=True)
    description=models.CharField(max_length=200,null=True)

    def __str__(self):
        return self.name











